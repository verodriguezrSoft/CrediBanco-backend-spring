package com.credibanco.assessment.card;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComCredibancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
